import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { verifySession } from "../lib/auth";
import { validateRequest } from "../lib/security";

export const config: Config = { path: "/api/admin/config" };

async function getUser(cookie: string | null) {
  if (!cookie) return null;
  const parts = cookie.split(";").map((s) => s.trim());
  const adminToken = parts.find((s) => s.startsWith("admin_session="))?.split("=")[1];
  const userToken = parts.find((s) => s.startsWith("session="))?.split("=")[1];
  const token = adminToken || userToken;
  if (!token) return null;
  try {
    return await verifySession(token);
  } catch (e) {
    return null;
  }
}

export default async (req: Request) => {
  // Anti-proxy/tampering check
  const security = await validateRequest(req);
  if (!security.valid) {
    return new Response(JSON.stringify({ error: "Security violation" }), { status: 403 });
  }

  const configStore = getStore({ name: "config", consistency: "strong" });

  // GET is for authenticated users (dashboard)
  if (req.method === 'GET') {
    const user = await getUser(req.headers.get("cookie"));
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });

    const embedUrl = await configStore.get('embed_url') || 'https://react-9b4n64.onspace.build/';
    return new Response(JSON.stringify({ embed_url: embedUrl }), { headers: { "Content-Type": "application/json" } });
  }

  // POST is admin only
  if (req.method === 'POST') {
    const user = await getUser(req.headers.get("cookie"));
    if (!user || user.role !== "admin") return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { embed_url } = body;
    if (!embed_url) return new Response(JSON.stringify({ error: "embed_url required" }), { status: 400 });

    await configStore.set('embed_url', embed_url);
    return new Response(JSON.stringify({ ok: true, embed_url }), { headers: { "Content-Type": "application/json" } });
  }

  return new Response('Method Not Allowed', { status: 405 });
}
