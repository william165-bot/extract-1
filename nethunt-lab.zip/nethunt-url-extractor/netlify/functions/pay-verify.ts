import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { verifySession, createSession, sessionCookie } from "../lib/auth";
import { toCanonicalGmail } from "../lib/email";

export const config: Config = { path: "/api/pay/verify" };

export default async (req: Request) => {
  const logs = getStore({ name: "payment-logs", consistency: "strong" });
  async function log(event: any) {
    try {
      const k = `log:${Date.now()}:${event?.tx || "no-tx"}`;
      await logs.setJSON(k, { time: Date.now(), ...event });
    } catch {}
  }

  try {
    const url = new URL(req.url);
    const txId = url.searchParams.get("transaction_id") || url.searchParams.get("transactionId") || url.searchParams.get("tx_id");
    if (!txId) {
      await log({ level: "warn", msg: "missing transaction_id" });
      return new Response(JSON.stringify({ error: "transaction_id missing" }), { status: 400 });
    }

    const cookie = req.headers.get("cookie") || "";
    const token = cookie.split(";").map((s) => s.trim()).find((s) => s.startsWith("session="))?.split("=")[1];
    if (!token) {
      await log({ level: "warn", tx: txId, msg: "no session" });
      return new Response(JSON.stringify({ error: "Not authenticated" }), { status: 401 });
    }

    let session: any;
    try { session = await verifySession(token); } catch {
      await log({ level: "warn", tx: txId, msg: "invalid session" });
      return new Response(JSON.stringify({ error: "Invalid session" }), { status: 401 });
    }

    const secret = process.env.FLW_SECRET_KEY;
    if (!secret) {
      await log({ level: "error", tx: txId, msg: "missing FLW_SECRET_KEY" });
      return new Response(JSON.stringify({ error: "Server payment config missing" }), { status: 500 });
    }

    const resp = await fetch(`https://api.flutterwave.com/v3/transactions/${encodeURIComponent(txId)}/verify`, {
      headers: { Authorization: `Bearer ${secret}`, Accept: "application/json" },
    });
    if (!resp.ok) {
      await log({ level: "error", tx: txId, msg: "verify fetch failed", status: resp.status });
      return new Response(JSON.stringify({ error: "Unable to verify payment" }), { status: 502 });
    }
    const body = await resp.json().catch(() => ({}));
    const data = body?.data || {};

    if (data?.status !== "successful") {
      await log({ level: "warn", tx: txId, msg: "payment not successful", status: data?.status });
      return new Response(JSON.stringify({ error: "Payment not successful" }), { status: 400 });
    }

    const userEmail = toCanonicalGmail(session?.email || '') || (session?.email || '').toLowerCase();
    if (!userEmail) {
      await log({ level: "warn", tx: txId, msg: "missing user email" });
      return new Response(JSON.stringify({ error: "Missing user email in session" }), { status: 400 });
    }

    // --- HACK PREVENTION: Cross-verify payment email with session email ---
    const flwCustomerEmail = toCanonicalGmail(data?.customer?.email || '') || (data?.customer?.email || '').toLowerCase();
    if (flwCustomerEmail && flwCustomerEmail !== userEmail) {
      await log({ level: "error", tx: txId, msg: "email mismatch - possible interception/replay", session_email: userEmail, flw_email: flwCustomerEmail });
      return new Response(JSON.stringify({ error: "Security check failed: Payment email does not match account email." }), { status: 403 });
    }

    const minAmount = parseInt(process.env.MIN_PAYMENT_AMOUNT || '100', 10);
    const maxAmount = parseInt(process.env.MAX_PAYMENT_AMOUNT || '5000', 10);
    const currencyList = (process.env.PAYMENT_CURRENCY_WHITELIST || process.env.PAYMENT_CURRENCY || 'NGN')
      .split(',').map(s=>s.trim().toUpperCase()).filter(Boolean);
    const refPrefix = (process.env.TX_REF_PREFIX || '').trim();

    const amount = Number(data?.amount || 0);
    const curr = (data?.currency || '').toUpperCase();
    const txRef = String(data?.tx_ref || '');

    if (refPrefix && !txRef.startsWith(refPrefix)) {
      await log({ level: "warn", tx: txId, msg: "tx_ref prefix mismatch", tx_ref: txRef });
      return new Response(JSON.stringify({ error: "Invalid transaction reference" }), { status: 400 });
    }

    if (!(amount >= minAmount && amount <= maxAmount)) {
      await log({ level: "warn", tx: txId, msg: "amount out of range", amount });
      return new Response(JSON.stringify({ error: "Invalid payment amount" }), { status: 400 });
    }

    if (!currencyList.includes(curr)) {
      await log({ level: "warn", tx: txId, msg: "currency not allowed", currency: curr });
      return new Response(JSON.stringify({ error: "Invalid payment currency" }), { status: 400 });
    }

    const payments = getStore({ name: "payments", consistency: "strong" });
    const txKey = `tx:${data.id}`;
    const already = (await payments.get(txKey, { type: "json" })) as any;
    if (already?.consumed) {
      await log({ level: "info", tx: txId, msg: "idempotent repeat", user_email: userEmail });
      return new Response(JSON.stringify({ ok: true, message: "Payment already processed" }), { headers: { "Content-Type": "application/json" } });
    }

    const users = getStore({ name: "users", consistency: "strong" });
    const uKey = `user:${userEmail}`;
    const user = (await users.get(uKey, { type: "json" })) as any;
    if (!user) {
      await log({ level: "error", tx: txId, msg: "user not found", user_email: userEmail });
      return new Response(JSON.stringify({ error: "User not found" }), { status: 404 });
    }

    user.premium = true;
    user.premium_activated_at = Date.now();
    user.premium_tx_id = data.id;
    user.premium_provider = "flutterwave";
    await users.setJSON(uKey, user);

    const rec = {
      id: data.id,
      status: data.status,
      amount: data.amount,
      currency: data.currency,
      tx_ref: data.tx_ref || null,
      processor_response: data.processor_response || null,
      customer_email: (data?.customer?.email || null),
      user_email: userEmail,
      consumed: true,
      consumed_at: Date.now(),
      consumed_by_email: userEmail,
    };
    await payments.setJSON(txKey, rec);

    const newToken = await createSession({ id: user.id, email: user.email, premium: true });
    await log({ level: "info", tx: txId, msg: "premium unlocked", user_email: userEmail, amount, currency: curr });

    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Set-Cookie": sessionCookie(newToken), "Content-Type": "application/json" },
    });
  } catch (e) {
    try {
      await getStore({ name: "payment-logs", consistency: "strong" }).setJSON(`log:${Date.now()}:error`, { time: Date.now(), level: "error", msg: "server error" });
    } catch {}
    return new Response(JSON.stringify({ error: "Server error" }), { status: 500 });
  }
}
