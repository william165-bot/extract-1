import type { Config } from "@netlify/functions";
import { createSession, adminSessionCookie } from "../lib/auth";

export const config: Config = { path: "/api/admin/login" };

export default async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 })
  const { username, password } = await req.json().catch(()=>({}))
  const u = process.env.ADMIN_USERNAME || 'nethunter'
  const p = process.env.ADMIN_PASSWORD || 'cbtpratice@nethunter'
  if (username === u && password === p) {
    const token = await createSession({ id: 'admin', email: 'admin@local', premium: true, role: 'admin' })
    return new Response(JSON.stringify({ ok: true }), { headers: { 'Set-Cookie': adminSessionCookie(token), 'Content-Type': 'application/json' } })
  }
  return new Response(JSON.stringify({ error: 'Invalid admin credentials' }), { status: 401 })
}
