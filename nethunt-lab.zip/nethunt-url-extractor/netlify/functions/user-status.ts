import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { verifySession, createSession, sessionCookie, clearSessionCookie } from "../lib/auth";
import { toCanonicalGmail } from "../lib/email";
import { validateRequest } from "../lib/security";

export const config: Config = { path: "/api/user/status" };

export default async (req: Request) => {
  try {
    // Anti-proxy/tampering check
    const security = await validateRequest(req);
    if (!security.valid) {
      return new Response(JSON.stringify({ error: "Security violation" }), { status: 403 });
    }

    const cookie = req.headers.get("cookie") || "";
    const token = cookie.split(";").map((s) => s.trim()).find((s) => s.startsWith("session="))?.split("=")[1];
    if (!token) return new Response(JSON.stringify({ user: null }), { headers: { "Content-Type": "application/json" } });

    let session: any;
    try { session = await verifySession(token); } catch { return new Response(JSON.stringify({ user: null }), { headers: { "Content-Type": "application/json" } }); }

    const users = getStore({ name: "users", consistency: "strong" });
    const canonical = toCanonicalGmail(session?.email || '') || (session?.email || '').toLowerCase();
    const uKey = `user:${canonical}`;
    let user = (await users.get(uKey, { type: "json" })) as any;
    if (!user) return new Response(JSON.stringify({ user: null }), { headers: { "Content-Type": "application/json" } });

    // --- BLOCK CHECK ---
    if (user.blocked) {
      return new Response(JSON.stringify({ user: null, blocked: true }), { 
        status: 403,
        headers: { 
          "Set-Cookie": clearSessionCookie(),
          "Content-Type": "application/json" 
        } 
      });
    }

    const now = Date.now();

    // --- VISIT TRACKING ---
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    if (!user.visits) user.visits = {};
    if (!user.visits[today]) user.visits[today] = 0;
    
    user.visits[today] += 1;
    user.last_visit_at = now;

    if (user.premium_expires_at && user.premium_expires_at < now && user.premium) {
      user.premium = false;
      user.premium_expired_at = now;
    }

    await users.setJSON(uKey, user);

    const refreshed = await createSession({ id: user.id, email: user.email, premium: !!user.premium });

    const payload = {
      id: user.id,
      email: user.email,
      name: user.name || "",
      created_at: user.created_at,
      premium: !!user.premium,
      premium_expires_at: user.premium_expires_at || null,
      trial_started_at: user.trial_started_at || null,
      trial_expires_at: user.trial_expires_at || null,
    };

    return new Response(JSON.stringify({ user: payload }), { headers: { "Set-Cookie": sessionCookie(refreshed), "Content-Type": "application/json" } });
  } catch {
    return new Response(JSON.stringify({ user: null }), { headers: { "Content-Type": "application/json" } });
  }
}
