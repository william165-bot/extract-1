import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { verifySession, createSession, sessionCookie } from "../lib/auth";
import { toCanonicalGmail } from "../lib/email";

export const config: Config = { path: "/api/pay/success" };

export default async (req: Request) => {
  try {
    const cookie = req.headers.get("cookie") || "";
    const token = cookie.split(";").map((s) => s.trim()).find((s) => s.startsWith("session="))?.split("=")[1];
    if (!token) return new Response(JSON.stringify({ error: "Not authenticated" }), { status: 401 });

    let session: any;
    try { session = await verifySession(token); } catch { return new Response(JSON.stringify({ error: "Invalid session" }), { status: 401 }); }

    const url = new URL(req.url);
    const txId = url.searchParams.get("transaction_id") || url.searchParams.get("transactionId") || url.searchParams.get("tx_id") || null;
    const status = (url.searchParams.get("status") || "").toLowerCase();
    const txRef = url.searchParams.get("tx_ref") || url.searchParams.get("txRef") || null;

    if (status !== "successful") {
      return new Response(JSON.stringify({ error: "Payment not successful" }), { status: 400 });
    }
    if (!txId || !/^\d{5,20}$/.test(String(txId))) {
      return new Response(JSON.stringify({ error: "Invalid transaction id" }), { status: 400 });
    }
    if (!txRef || String(txRef).length < 6 || String(txRef).length > 128) {
      return new Response(JSON.stringify({ error: "Invalid transaction reference" }), { status: 400 });
    }

    const users = getStore({ name: "users", consistency: "strong" });
    const canonical = toCanonicalGmail(session?.email || '') || (session?.email || '').toLowerCase();
    const uKey = `user:${canonical}`;
    const user = (await users.get(uKey, { type: "json" })) as any;
    if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404 });

    const payments = getStore({ name: "payments", consistency: "strong" });
    const txKey = `tx:${txId}`;
    const existing = (await payments.get(txKey, { type: "json" })) as any;
    if (existing?.consumed) {
      if (existing.user_email && existing.user_email !== user.email) {
        return new Response(JSON.stringify({ error: "Transaction already used" }), { status: 400 });
      }
      return new Response(JSON.stringify({ ok: true, message: "Payment already processed" }), { headers: { "Content-Type": "application/json" } });
    }

    user.premium = true;
    const now = Date.now();
    user.premium_activated_at = now;
    user.premium_expires_at = now + 30 * 24 * 60 * 60 * 1000;
    user.premium_tx_id = txId;
    user.premium_provider = "flutterwave_redirect";
    await users.setJSON(uKey, user);

    const rec = {
      id: txId,
      status,
      tx_ref: txRef,
      user_email: user.email,
      consumed: true,
      consumed_at: Date.now(),
      provider: "flutterwave_redirect",
    };
    try { await payments.setJSON(txKey, rec); } catch {}

    const newToken = await createSession({ id: user.id, email: user.email, premium: true });
    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Set-Cookie": sessionCookie(newToken), "Content-Type": "application/json" },
    });
  } catch {
    return new Response(JSON.stringify({ error: "Server error" }), { status: 500 });
  }
}
