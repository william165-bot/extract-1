import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { verifyPassword } from "../lib/hash";
import { createSession, sessionCookie } from "../lib/auth";
import { toCanonicalGmail } from "../lib/email";

export const config: Config = { path: "/api/auth/signin" };

export default async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 })
  const body = await req.json().catch(() => ({}))
  const { email, password } = body
  if (!email || !password) return new Response(JSON.stringify({ error: 'email and password required' }), { status: 400 })
  const canonical = toCanonicalGmail(email)
  if (!canonical) return new Response(JSON.stringify({ error: 'Only Gmail addresses are allowed' }), { status: 400 })
  const users = getStore({ name: 'users' })
  const key = `user:${canonical}`
  const user = await users.get(key, { type: 'json' }) as any
  if (!user) return new Response(JSON.stringify({ error: 'Invalid credentials' }), { status: 401 })
  if (!verifyPassword(password, user.password_hash)) return new Response(JSON.stringify({ error: 'Invalid credentials' }), { status: 401 })
  const token = await createSession({ id: user.id, email: user.email, premium: user.premium })
  return new Response(JSON.stringify({ ok: true }), { headers: { 'Set-Cookie': sessionCookie(token), 'Content-Type': 'application/json' } })
}
