import type { Config } from "@netlify/functions";
import { clearSessionCookie } from "../lib/auth";

export const config: Config = { path: "/api/auth/logout" };

export default async () => {
  return new Response(JSON.stringify({ ok: true }), { headers: { 'Set-Cookie': clearSessionCookie(), 'Content-Type': 'application/json' } })
}
