import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { verifySession } from "../lib/auth";
import { toCanonicalGmail } from "../lib/email";

export const config: Config = { path: "/api/admin/revoke" };

async function isAdmin(cookie: string | null) {
  if (!cookie) return false;
  const parts = cookie.split(";").map((s) => s.trim());
  const adminToken = parts.find((s) => s.startsWith("admin_session="))?.split("=")[1];
  const userToken = parts.find((s) => s.startsWith("session="))?.split("=")[1];
  const token = adminToken || userToken;
  if (!token) return false;
  return verifySession(token).then((p) => p.role === "admin").catch(() => false);
}

export default async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });
  const admin = await isAdmin(req.headers.get("cookie"));
  if (!admin) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });

  const { email } = await req.json().catch(()=>({}));
  if (!email) return new Response(JSON.stringify({ error: 'email required' }), { status: 400 });

  const users = getStore({ name: "users", consistency: "strong" });
  const canonical = toCanonicalGmail(String(email)) || String(email).toLowerCase();
  const key = `user:${canonical}`;
  const user = await users.get(key, { type: 'json' }) as any;
  if (!user) return new Response(JSON.stringify({ error: 'User not found' }), { status: 404 });

  user.premium = false;
  user.premium_revoked_at = Date.now();
  await users.setJSON(key, user);

  return new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json' } });
}
