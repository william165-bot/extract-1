import type { Config } from "@netlify/functions";
import { getDeviceId, newDeviceId, deviceCookie } from "../lib/device";

export const config: Config = { path: "/api/trial/seed" };

export default async (req: Request) => {
  const id = getDeviceId(req) || newDeviceId();
  const headers = new Headers({ 'Content-Type': 'application/json' });
  headers.append('Set-Cookie', deviceCookie(id));
  return new Response(JSON.stringify({ ok: true, id }), { headers });
}
