import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { nanoid } from "nanoid/non-secure";
import { hashPassword } from "../lib/hash";
import { createSession, sessionCookie } from "../lib/auth";
import { toCanonicalGmail } from "../lib/email";
import { getDeviceId, newDeviceId, deviceCookie } from "../lib/device";
import { computeFingerprint, clientIp } from "../lib/fingerprint";

export const config: Config = { path: "/api/auth/signup" };

export default async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 })
  const body = await req.json().catch(() => ({}))
  const { email, password, name } = body
  if (!email || !password) return new Response(JSON.stringify({ error: 'email and password required' }), { status: 400 })

  const ip = clientIp(req)
  try {
    const rate = getStore({ name: 'rates', consistency: 'strong' })
    const bucket = Math.floor(Date.now() / (60 * 60 * 1000))
    const rKey = `signup:${ip}:${bucket}`
    const rec = (await rate.get(rKey, { type: 'json' })) as any || { count: 0 }
    if (rec.count >= 5) return new Response(JSON.stringify({ error: 'Too many attempts, try later' }), { status: 429 })
    rec.count += 1; rec.updated_at = Date.now()
    await rate.setJSON(rKey, rec)
  } catch {}

  const canonical = toCanonicalGmail(email)
  if (!canonical) return new Response(JSON.stringify({ error: 'Only Gmail addresses are allowed' }), { status: 400 })
  const users = getStore({ name: 'users', consistency: 'strong' })
  const key = `user:${canonical}`
  const existing = await users.get(key, { type: 'json' }) as any
  if (existing) return new Response(JSON.stringify({ error: 'Account already exists' }), { status: 409 })

  const id = nanoid()
  const password_hash = hashPassword(password)
  const now = Date.now()

  const trials = getStore({ name: 'trials', consistency: 'strong' })
  let deviceId = getDeviceId(req)
  if (!deviceId) deviceId = newDeviceId()
  const dKey = `dev:${deviceId}`
  const dev = (await trials.get(dKey, { type: 'json' })) as any
  const fp = computeFingerprint(req)
  const fKey = `fp:${fp}`
  const fRec = (await trials.get(fKey, { type: 'json' })) as any
  const alreadyClaimed = !!(dev && dev.claimed) || !!(fRec && fRec.claimed)

  if (alreadyClaimed) {
    return new Response(JSON.stringify({ error: 'Free trial already claimed on this device/network. Please sign in to your existing account or upgrade to Premium.' }), { status: 403 })
  }

  const record: any = { id, email: canonical, name: name || '', password_hash, premium: false, created_at: now }
  record.trial_started_at = now
  record.trial_expires_at = now + 28 * 24 * 60 * 60 * 1000
  
  await users.setJSON(key, record)

  await trials.setJSON(dKey, { claimed: true, claimed_at: now, email: canonical })
  await trials.setJSON(fKey, { claimed: true, claimed_at: now, email: canonical })

  const token = await createSession({ id, email: record.email, premium: record.premium })
  const headers = new Headers({ 'Content-Type': 'application/json' })
  headers.append('Set-Cookie', sessionCookie(token))
  headers.append('Set-Cookie', deviceCookie(deviceId))
  return new Response(JSON.stringify({ ok: true }), { status: 200, headers })
}
