import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { verifySession } from "../lib/auth";
import { toCanonicalGmail } from "../lib/email";

export const config: Config = { path: "/api/admin/block" };

async function isAdmin(cookie: string | null) {
  if (!cookie) return false;
  const parts = cookie.split(";").map((s) => s.trim());
  const adminToken = parts.find((s) => s.startsWith("admin_session="))?.split("=")[1];
  const userToken = parts.find((s) => s.startsWith("session="))?.split("=")[1];
  const token = adminToken || userToken;
  if (!token) return false;
  try {
    const payload = await verifySession(token);
    return payload.role === "admin";
  } catch {
    return false;
  }
}

export default async (req: Request) => {
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  const admin = await isAdmin(req.headers.get("cookie"));
  if (!admin) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });

  const body = await req.json().catch(() => ({}));
  const { email, block } = body;
  if (!email) return new Response(JSON.stringify({ error: "Email required" }), { status: 400 });

  const users = getStore({ name: "users", consistency: "strong" });
  const canonical = toCanonicalGmail(email) || email.toLowerCase();
  const uKey = `user:${canonical}`;
  
  const user = (await users.get(uKey, { type: "json" })) as any;
  if (!user) return new Response(JSON.stringify({ error: "User not found" }), { status: 404 });

  user.blocked = !!block;
  user.blocked_at = block ? Date.now() : null;
  
  await users.setJSON(uKey, user);

  return new Response(JSON.stringify({ ok: true, blocked: user.blocked }), { headers: { "Content-Type": "application/json" } });
}
