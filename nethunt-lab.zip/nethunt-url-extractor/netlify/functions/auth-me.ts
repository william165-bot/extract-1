import type { Config } from "@netlify/functions";
import { verifySession } from "../lib/auth";

export const config: Config = { path: "/api/auth/me" };

export default async (req: Request) => {
  const cookie = req.headers.get('cookie') || ''
  const token = cookie.split(';').map(s=>s.trim()).find(s=>s.startsWith('session='))?.split('=')[1]
  if (!token) return new Response(JSON.stringify({ user: null }), { headers: { 'Content-Type': 'application/json' } })
  try {
    const payload = await verifySession(token)
    return new Response(JSON.stringify({ user: payload }), { headers: { 'Content-Type': 'application/json' } })
  } catch {
    return new Response(JSON.stringify({ user: null }), { headers: { 'Content-Type': 'application/json' } })
  }
}
