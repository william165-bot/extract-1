import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { verifySession } from "../lib/auth";

export const config: Config = { path: "/api/admin/users" };

async function isAdmin(cookie: string | null) {
  if (!cookie) return false;
  const parts = cookie.split(";").map((s) => s.trim());
  const adminToken = parts.find((s) => s.startsWith("admin_session="))?.split("=")[1];
  const userToken = parts.find((s) => s.startsWith("session="))?.split("=")[1];
  const token = adminToken || userToken;
  if (!token) return false;
  return verifySession(token).then((p) => p.role === "admin").catch(() => false);
}

export default async (req: Request) => {
  const admin = await isAdmin(req.headers.get("cookie"));
  if (!admin) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });

  const users = getStore({ name: "users", consistency: "strong" });
  const list = await users.list({ prefix: "user:" });
  const items = await Promise.all(list.blobs.map((b) => users.get(b.key, { type: "json" })));
  const all = (items as any[]).filter(Boolean).map((u) => ({
    id: u.id,
    email: u.email,
    created_at: u.created_at || null,
    premium: !!u.premium,
    premium_expires_at: u.premium_expires_at || null,
    trial_expires_at: u.trial_expires_at || null,
    visits: u.visits || {},
    last_visit_at: u.last_visit_at || null,
    blocked: !!u.blocked,
  }));
  return new Response(JSON.stringify(all), { headers: { "Content-Type": "application/json" } });
}
