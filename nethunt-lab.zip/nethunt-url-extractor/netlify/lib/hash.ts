import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto'

export function hashPassword(password: string) {
  const salt = randomBytes(16)
  const N = 16384, r = 8, p = 1, dkLen = 64
  const hash = scryptSync(password, salt, dkLen, { N, r, p })
  return `scrypt$${N}$${r}$${p}$${salt.toString('base64')}$${hash.toString('base64')}`
}

export function verifyPassword(password: string, encoded: string) {
  const [scheme, Ns, rs, ps, saltB64, hashB64] = encoded.split('$')
  if (scheme !== 'scrypt') return false
  const N = parseInt(Ns, 10), r = parseInt(rs, 10), p = parseInt(ps, 10)
  const salt = Buffer.from(saltB64, 'base64')
  const expected = Buffer.from(hashB64, 'base64')
  const actual = scryptSync(password, salt, expected.length, { N, r, p })
  return timingSafeEqual(actual, expected)
}
