export function toCanonicalGmail(raw: string): string | null {
  if (!raw) return null;
  const lower = String(raw).trim().toLowerCase();
  const at = lower.lastIndexOf('@');
  if (at <= 0) return null;
  let local = lower.slice(0, at);
  let domain = lower.slice(at + 1);
  if (domain === 'googlemail.com') domain = 'gmail.com';
  if (domain !== 'gmail.com') return null;
  const plus = local.indexOf('+');
  if (plus !== -1) local = local.slice(0, plus);
  local = local.replace(/\./g, '');
  if (!/^[a-z0-9_\-]{1,64}$/.test(local)) return null;
  return `${local}@gmail.com`;
}
