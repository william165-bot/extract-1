import { createHmac } from 'node:crypto'

export function clientIp(req: Request): string {
  const h = req.headers
  const a = (h.get('x-nf-client-connection-ip') || h.get('x-real-ip') || h.get('x-forwarded-for') || h.get('client-ip') || '').split(',')[0].trim()
  return a || '0.0.0.0'
}

export function computeFingerprint(req: Request): string {
  const ip = clientIp(req)
  const ua = req.headers.get('user-agent') || ''
  const lang = req.headers.get('accept-language') || ''
  const raw = `${ip}|${ua}|${lang}`
  const secret = process.env.TRIAL_FINGERPRINT_SECRET || process.env.JWT_SECRET || 'dev-secret'
  const h = createHmac('sha256', secret).update(raw).digest('hex')
  return `fp_${h.slice(0, 32)}`
}
