import { SignJWT, jwtVerify } from 'jose'

const encoder = new TextEncoder()

export const getJwtSecret = () => {
  const s = process.env.JWT_SECRET || process.env.NETLIFY_SITE_ID || 'dev-secret'
  return encoder.encode(s)
}

export async function createSession(user: { id: string; email: string; premium?: boolean; role?: string }) {
  const token = await new SignJWT({ sub: user.id, email: user.email, premium: !!user.premium, role: user.role || 'user' })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(getJwtSecret())
  return token
}

export async function verifySession(token: string) {
  const { payload } = await jwtVerify(token, getJwtSecret())
  return payload as any
}

export function sessionCookie(token: string) {
  return `session=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${60 * 60 * 24 * 7}`
}

export function clearSessionCookie() {
  return `session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`
}

export function adminSessionCookie(token: string) {
  return `admin_session=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${60 * 60 * 24 * 7}`
}

export function clearAdminSessionCookie() {
  return `admin_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`
}
