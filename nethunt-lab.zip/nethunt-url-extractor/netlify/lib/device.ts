import { nanoid } from "nanoid/non-secure";

export function parseCookie(cookie: string | null): Record<string, string> {
  const out: Record<string, string> = {};
  if (!cookie) return out;
  for (const part of cookie.split(';')) {
    const [k, ...rest] = part.trim().split('=');
    if (!k) continue;
    out[k] = rest.join('=');
  }
  return out;
}

export function getDeviceId(req: Request): string | null {
  const cookie = req.headers.get('cookie') || '';
  const map = parseCookie(cookie);
  return map['trial_device'] || null;
}

export function newDeviceId() {
  return `dev_${nanoid(16)}`;
}

export function deviceCookie(id: string) {
  return `trial_device=${id}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${60*60*24*365}`;
}
