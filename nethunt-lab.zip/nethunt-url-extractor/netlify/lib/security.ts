export async function validateRequest(req: Request) {
  const headers = req.headers;
  const userAgent = headers.get("user-agent") || "";
  
  // 1. Detect common proxy/interception headers
  const proxyHeaders = [
    "x-forwarded-for",
    "via",
    "forwarded",
    "x-forwarded-proto",
    "x-forwarded-host",
    "proxy-connection"
  ];
  
  // Note: Netlify uses some of these, so we check for suspicious values or combinations
  // Burp Suite often adds specific headers or patterns
  
  // 2. Check for suspicious User-Agents (automated tools)
  const suspiciousUAs = [
    "burp",
    "postman",
    "curl",
    "wget",
    "python-requests",
    "insomnia"
  ];
  
  if (suspiciousUAs.some(ua => userAgent.toLowerCase().includes(ua))) {
    return { valid: false, reason: "Automated tool detected" };
  }

  // 3. Custom Security Header (Anti-Tampering)
  // We expect a custom header that the frontend generates
  const securityToken = headers.get("x-app-security-token");
  if (!securityToken) {
    // For now, we might just log this or return false if we want to be strict
    // return { valid: false, reason: "Missing security token" };
  }

  return { valid: true };
}

export function getSecurityHeaders() {
  // Generate a simple time-based token or similar
  // In a real app, this would be more complex (e.g., HMAC)
  const timestamp = Date.now();
  const token = btoa(`nethunt-${timestamp}`);
  return {
    "x-app-security-token": token,
    "x-content-type-options": "nosniff",
    "x-frame-options": "DENY",
    "strict-transport-security": "max-age=31536000; includeSubDomains"
  };
}
