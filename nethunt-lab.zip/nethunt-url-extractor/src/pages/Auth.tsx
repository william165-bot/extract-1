import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { api } from '@/lib/api'
import { useNavigate, useSearchParams } from 'react-router-dom'

export default function AuthPage() {
  const [mode, setMode] = useState<'signin'|'signup'>('signin')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const nav = useNavigate()
  const [searchParams] = useSearchParams()
  useEffect(() => {
    const m = searchParams.get('mode')
    if (m === 'signup' || m === 'signin') setMode(m as any)
    fetch('/api/trial/seed').catch(()=>{})
  }, [searchParams])

  async function submit() {
    setLoading(true); setError('')
    try {
      if (mode === 'signup') await api('/auth/signup', { method: 'POST', body: JSON.stringify({ email, password, name }) })
      else await api('/auth/signin', { method: 'POST', body: JSON.stringify({ email, password }) })
      nav('/dashboard')
    } catch (e: any) {
      setError(e?.error || 'An error occurred')
    } finally { setLoading(false) }
  }

  return (
    <div className="mx-auto max-w-md p-6">
      <h1 className="mb-2 text-3xl font-serif">AI Experiment Lab Report</h1>
      <p className="mb-6 text-muted-foreground">Sign {mode==='signin'?'in':'up'} to start your 28-day free trial.</p>

      <div className="mb-4 flex gap-2">
        <Button variant={mode==='signin'?'default':'outline'} onClick={()=>setMode('signin')}>Sign in</Button>
        <Button variant={mode==='signup'?'default':'outline'} onClick={()=>setMode('signup')}>Sign up</Button>
      </div>

      {mode==='signup' && (
        <div className="mb-3">
          <label className="text-sm">Full Name</label>
          <Input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" />
        </div>
      )}
      <div className="mb-3">
        <label className="text-sm">Email</label>
        <Input value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" type="email" />
      </div>
      <div className="mb-4">
        <label className="text-sm">Password</label>
        <Input value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••" type="password" />
      </div>

      {error && <div className="mb-4 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}

      <Button onClick={submit} disabled={loading} className="w-full">{loading?'Please wait...': (mode==='signin'?'Sign in':'Create account')}</Button>
    </div>
  )
}
