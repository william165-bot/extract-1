import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { api } from '@/lib/api'
import { useNavigate } from 'react-router-dom'

export default function AdminLogin() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const nav = useNavigate()

  async function submit() {
    setLoading(true); setError('')
    try {
      await api('/admin/login', { method: 'POST', body: JSON.stringify({ username, password }) })
      nav('/admin')
    } catch (e: any) {
      setError(e?.error || 'Login failed')
    } finally { setLoading(false) }
  }

  return (
    <div className="mx-auto max-w-md p-6">
      <h1 className="mb-2 text-3xl font-serif">Admin Portal</h1>

      <div className="mb-3">
        <label className="text-sm">Admin Name</label>
        <Input value={username} onChange={e=>setUsername(e.target.value)} placeholder="example" />
      </div>
      <div className="mb-4">
        <label className="text-sm">Password</label>
        <Input value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••" type="password" />
      </div>
      {error && <div className="mb-4 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}
      <Button className="w-full" onClick={submit} disabled={loading}>{loading? 'Please wait...' : 'Sign in'}</Button>
    </div>
  )
}
