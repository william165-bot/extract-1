import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export default function AdminPanel() {
  const [users, setUsers] = useState<any[]>([])
  const [subs, setSubs] = useState<any[]>([])
  const [grantEmail, setGrantEmail] = useState('')
  const [grantMonths, setGrantMonths] = useState<number>(1)
  const [embedUrl, setEmbedUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function load() {
    const cr = await fetch('/api/admin/config')
    if (cr.ok) {
      const config = await cr.json()
      setEmbedUrl(config.embed_url)
    }
    const ur = await fetch('/api/admin/users')
    if (!ur.ok) { setError('Unauthorized'); return }
    setUsers(await ur.json())
    const sr = await fetch('/api/admin/subscribers')
    if (sr.ok) setSubs(await sr.json())
  }

  useEffect(()=>{ load() }, [])

  async function grant(email: string, months = 1) {
    setLoading(true); setError('')
    try {
      const r = await fetch('/api/admin/grant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, months }) })
      if (!r.ok) throw new Error('Failed to grant')
      await load(); setGrantEmail('')
    } catch (e:any) { setError(e.message) } finally { setLoading(false) }
  }

  async function revoke(email: string) {
    setLoading(true); setError('')
    try {
      const r = await fetch('/api/admin/revoke', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email }) })
      if (!r.ok) throw new Error('Failed to revoke')
      await load()
    } catch (e:any) { setError(e.message) } finally { setLoading(false) }
  }

  async function toggleBlock(email: string, currentBlocked: boolean) {
    setLoading(true); setError('')
    try {
      const r = await fetch('/api/admin/block', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json' }, 
        body: JSON.stringify({ email, block: !currentBlocked }) 
      })
      if (!r.ok) throw new Error('Failed to update block status')
      await load()
    } catch (e:any) { setError(e.message) } finally { setLoading(false) }
  }

  async function updateLink() {
    setLoading(true); setError('')
    try {
      const r = await fetch('/api/admin/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ embed_url: embedUrl }) })
      if (!r.ok) throw new Error('Failed to update link')
      alert('Link updated successfully!')
    } catch (e:any) { setError(e.message) } finally { setLoading(false) }
  }

  return (
    <div className="mx-auto max-w-4xl p-6">
      <h1 className="mb-2 text-3xl font-serif">Admin Dashboard</h1>

      <div className="mb-6 rounded-lg border p-4">
        <div className="mb-2 font-medium">Manage Embedded Tool Link</div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input placeholder="https://..." value={embedUrl} onChange={e=>setEmbedUrl(e.target.value)} className="flex-1" />
          <Button onClick={updateLink} disabled={loading || !embedUrl}>Update Link</Button>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">This link will be loaded in the iframe on the user dashboard.</p>
      </div>

      <div className="mb-6 rounded-lg border p-4">
        <div className="mb-2 font-medium">Grant Premium</div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input placeholder="user@example.com" value={grantEmail} onChange={e=>setGrantEmail(e.target.value)} />
          <Input type="number" min={1} placeholder="months" value={grantMonths} onChange={e=>setGrantMonths(parseInt(e.target.value||'1',10))} className="w-28" />
          <Button onClick={()=>grant(grantEmail, grantMonths)} disabled={loading || !grantEmail}>Grant</Button>
        </div>
        {error && <div className="mt-3 rounded-md border border-destructive/30 bg-destructive/10 p-2 text-xs text-destructive">{error}</div>}
      </div>

      <div className="mb-6 rounded-lg border">
        <div className="border-b p-3 font-medium">All Users</div>
        <div className="divide-y">
          {users.map((u:any)=> (
            <div key={u.email} className={`flex items-center justify-between p-3 text-sm ${u.blocked ? 'bg-destructive/5' : ''}`}>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{u.email}</span>
                  {u.blocked && <span className="rounded bg-destructive px-1.5 py-0.5 text-[10px] font-bold uppercase text-destructive-foreground">Blocked</span>}
                </div>
                <div className="text-muted-foreground">Created: {u.created_at ? new Date(u.created_at).toLocaleString() : 'N/A'} • Status: {u.premium ? 'Premium' : 'Free/Expired'}</div>
                <div className="mt-1 text-xs text-primary">
                  Today's Visits: {u.visits?.[new Date().toISOString().split('T')[0]] || 0} 
                  {u.last_visit_at && ` • Last seen: ${new Date(u.last_visit_at).toLocaleString()}`}
                </div>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant={u.blocked ? "default" : "outline"} 
                  size="sm"
                  onClick={()=>toggleBlock(u.email, u.blocked)} 
                  disabled={loading}
                  className={u.blocked ? "" : "text-destructive hover:bg-destructive/10 hover:text-destructive"}
                >
                  {u.blocked ? 'Unblock' : 'Block'}
                </Button>
                {!u.premium && <Button variant="outline" size="sm" onClick={()=>grant(u.email, 1)} disabled={loading}>Grant 1 mo</Button>}
                {u.premium && <Button variant="outline" size="sm" onClick={()=>revoke(u.email)} disabled={loading}>Revoke</Button>}
              </div>
            </div>
          ))}
          {users.length===0 && <div className="p-3 text-sm text-muted-foreground">No users yet.</div>}
        </div>
      </div>

      <div className="rounded-lg border">
        <div className="border-b p-3 font-medium">Active Subscribers</div>
        <div className="divide-y">
          {subs.map((u:any)=> (
            <div key={u.email} className="flex items-center justify-between p-3 text-sm">
              <div>
                <div className="font-medium">{u.email}</div>
                <div className="text-muted-foreground">TX: {u.premium_tx_id || 'N/A'} • Activated: {u.premium_activated_at ? new Date(u.premium_activated_at).toLocaleString() : 'N/A'} • Expires: {u.premium_expires_at ? new Date(u.premium_expires_at).toLocaleString() : 'N/A'}</div>
              </div>
              <Button variant="outline" onClick={()=>revoke(u.email)} disabled={loading}>Revoke</Button>
            </div>
          ))}
          {subs.length===0 && <div className="p-3 text-sm text-muted-foreground">No active subscribers.</div>}
        </div>
      </div>
    </div>
  )
}
