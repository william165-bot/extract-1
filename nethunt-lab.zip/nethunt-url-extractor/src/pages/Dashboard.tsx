import { useEffect, useMemo, useState, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { useNavigate } from 'react-router-dom'
import { Lock } from 'lucide-react'
import { api } from '@/lib/api'

const PAY_URL = 'https://flutterwave.com/pay/7k8wh62jmtzh'

export default function Dashboard() {
  const [record, setRecord] = useState<any>(null)
  const [embedUrl, setEmbedUrl] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const nav = useNavigate()

  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        // Use the secured api wrapper
        const me = await api<any>('/auth/me').catch(() => ({ user: null }))
        if (!me.user) { nav('/auth?mode=signup', { replace: true }); return }
        
        const rec = await api<any>('/user/status').catch(() => ({ user: null }))
        if (!rec.user) { nav('/auth?mode=signup', { replace: true }); return }
        
        if (isMounted) {
          setRecord(rec.user)
          
          const now = Date.now()
          const isPremiumActive = !!rec.user?.premium && (!rec.user?.premium_expires_at || rec.user?.premium_expires_at > now)
          const isTrialActive = !!rec.user?.trial_expires_at && rec.user.trial_expires_at > now
          
          if (isPremiumActive || isTrialActive) {
            try {
              // Fetch from secured config endpoint
              const config = await api<any>('/admin/config')
              if (config.embed_url && isMounted) {
                // Obfuscation: Delay the setting of the URL slightly
                setTimeout(() => {
                  if (isMounted) setEmbedUrl(config.embed_url)
                }, 500);
              }
            } catch (e) {
              console.error("Failed to fetch dynamic config", e)
            }
          }
        }
      } catch (err) {
        console.error("Dashboard init error", err)
      } finally {
        if (isMounted) setLoading(false)
      }
    })()

    // Anti-Inspection: Clear URL on unmount and try to prevent right-click on iframe area
    return () => {
      isMounted = false
      setEmbedUrl(null)
    }
  }, [nav])

  const now = Date.now()
  const isPremiumActive = useMemo(() => !!record?.premium && (!record?.premium_expires_at || record?.premium_expires_at > now), [record, now])
  const isTrialActive = useMemo(() => !!record?.trial_expires_at && record.trial_expires_at > now, [record, now])

  const canUse = isPremiumActive || isTrialActive

  return (
    <div className="mx-auto max-w-[1800px] p-6" onContextMenu={(e) => e.preventDefault()}>
      <h1 className="mb-1 text-3xl font-serif">Welcome{record?.email?`, ${record.email}`:''}</h1>
      <p className="mb-6 text-muted-foreground">AI Experiment Lab Report — Advanced reporting for Engineering and Physics.</p>

      <div className="grid gap-6 xl:grid-cols-5">
        <Card className="xl:col-span-4">
          <CardHeader>
            <CardTitle>Lab Report Generator</CardTitle>
            <CardDescription>{canUse ? 'Input your experiment data inside the AI tool' : 'Start a free trial or upgrade to Premium to use the lab tools'}</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="py-20 text-center text-sm text-muted-foreground">Loading…</div>
            ) : canUse && embedUrl ? (
              <div className="relative overflow-hidden rounded-xl border bg-background">
                <div className="relative w-full overflow-hidden min-h-[720px] md:min-h-[860px] lg:min-h-[960px] xl:min-h-[1080px]">
                  {/* Overlay to prevent direct interaction with iframe source via right click */}
                  <div className="absolute inset-0 z-10 bg-transparent pointer-events-none" />
                  
                  <iframe
                    ref={iframeRef}
                    src={embedUrl}
                    title="AI Lab Report"
                    className="h-[1500px] w-full -translate-y-[40px] transform"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"
                  />
                  
                  {/* Visual gradients to hide tool headers/footers */}
                  <div className="pointer-events-none absolute left-0 top-0 z-20 h-16 w-full bg-gradient-to-b from-background to-transparent"/>
                  <div className="pointer-events-none absolute bottom-0 left-0 z-20 h-28 w-full bg-gradient-to-t from-background to-transparent"/>
                </div>
              </div>
            ) : canUse && !embedUrl ? (
              <div className="py-20 text-center text-sm text-muted-foreground">Initializing secure environment...</div>
            ) : (
              <div className="relative overflow-hidden rounded-xl border bg-muted/10 p-6">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Lock className="h-4 w-4" />
                  <span>Access locked</span>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">Your free trial has ended. Upgrade to continue using AI Experiment Lab Report.</p>
                <div className="mt-4">
                  <a href={PAY_URL} target="_blank" rel="noopener noreferrer">
                    <Button>Upgrade with Flutterwave</Button>
                  </a>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6 xl:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Account</CardTitle>
              <CardDescription>Plan and limits</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div><span className="text-muted-foreground">Email:</span> {record?.email}</div>
                <div><span className="text-muted-foreground">Status:</span> {isPremiumActive ? 'Premium' : (isTrialActive ? 'Free trial' : 'Locked')}</div>
                {isTrialActive && record?.trial_expires_at && (
                  <div><span className="text-muted-foreground">Trial ends:</span> {new Date(record.trial_expires_at).toLocaleString()}</div>
                )}
                {isPremiumActive && record?.premium_expires_at && (
                  <div><span className="text-muted-foreground">Premium ends:</span> {new Date(record.premium_expires_at).toLocaleString()}</div>
                )}
                {!isPremiumActive && (
                  <div className="pt-2">
                    <a href={PAY_URL} target="_blank" rel="noopener noreferrer">
                      <Button className="w-full">Upgrade to Premium</Button>
                    </a>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="rounded-lg border p-4 text-sm text-muted-foreground">
            <div className="font-medium text-foreground">How it works</div>
            <ul className="mt-2 list-disc pl-5 space-y-1">
              <li>Input your experiment parameters and data from Engineering or Physics labs into the AI tool.</li>
              <li>The AI generates a structured report based on your inputs.</li>
              <li>The display width is responsive and extended for better data visualization, automatically adjusting to your screen size.</li>
            </ul>
            <div className="mt-3 text-foreground">
          For issues, contact the developer at:
          <div className="mt-1 flex flex-col gap-1">
            <span>Whatsapp: <a href="https://wa.me/2348138474528" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">+2348138474528</a></span>
            <span>Telegram: <a href="https://t.me/Net_hunter_supreme" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">https://t.me/Net_hunter_supreme</a></span>
          </div>
        </div>
          </div>
        </div>
      </div>
    </div>
  )
}
