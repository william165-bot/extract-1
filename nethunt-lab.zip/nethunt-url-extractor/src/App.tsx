import { useEffect, useState } from 'react'
import { Button } from "@/components/ui/button";
import { BrowserRouter, Link, Route, Routes, useNavigate } from 'react-router-dom'
import AuthPage from './pages/Auth'
import Dashboard from './pages/Dashboard'
import AdminLogin from './pages/AdminLogin'
import AdminPanel from './pages/AdminPanel'

function NavBar() {
  const nav = useNavigate()
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
        <Link to="/" className="font-serif text-xl">AI Experiment Lab Report</Link>
        <nav className="flex items-center gap-2 text-sm">
          <Link className="hover:underline" to="/dashboard">Dashboard</Link>
          <Link className="hover:underline" to="/admin/login">Admin</Link>
          <Button variant="outline" onClick={async()=>{ await fetch('/api/auth/logout'); nav('/auth') }}>Logout</Button>
        </nav>
      </div>
    </header>
  )
}

export default function Home() {
  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/dashboard" element={<Dashboard />} />

        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/admin" element={<AdminPanel />} />
      </Routes>
    </BrowserRouter>
  );
}

function Landing() {
  const nav = useNavigate()
  const [status, setStatus] = useState<{ state: 'idle'|'verifying'|'success'|'error'; message?: string }>({ state: 'idle' })

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const tx = params.get('transaction_id') || params.get('transactionId') || params.get('tx_id') || params.get('status') || params.get('tx_ref') || params.get('txRef')
    if (tx) {
      setStatus({ state: 'verifying', message: 'Activating premium…' })
      fetch(`/api/pay/success${window.location.search}`)
        .then(async r => {
          if (!r.ok) throw await r.json().catch(()=>({ error: 'Activation failed' }))
          return r.json()
        })
        .then(() => {
          setStatus({ state: 'success', message: 'Premium unlocked!' })
          setTimeout(() => nav('/dashboard', { replace: true }), 1000)
        })
        .catch((e:any) => {
          setStatus({ state: 'error', message: e?.error || 'Activation failed' })
        })
    }
  }, [nav])

  return (
    <div className="flex min-h-[calc(100vh-56px)] flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-background via-background to-background">
      <main className="container relative z-10 flex max-w-4xl flex-col items-center justify-center gap-10 px-4 py-16 text-center md:py-24">
        {status.state !== 'idle' && (
          <div className={`rounded-lg border p-3 text-sm ${status.state==='error'?'border-destructive/30 bg-destructive/10 text-destructive':'border-muted-foreground/30 bg-muted/10 text-muted-foreground'}`}>
            {status.message}
          </div>
        )}
        <div className="space-y-8">
          <h1 className="font-serif text-4xl font-light tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
            AI-Powered Lab Reports for Engineering & Physics
          </h1>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground md:text-xl">
            Generate comprehensive experiment reports with precision. Sign up, enjoy a 28-day free trial, then upgrade securely with Flutterwave for uninterrupted access to advanced lab tools.
          </p>
        </div>
        <div className="flex flex-col gap-4 sm:flex-row">
          <Link to="/auth">
            <Button size="lg" className="group">
              <span>Sign in / Sign up</span>
            </Button>
          </Link>
          <Link to="/dashboard">
            <Button variant="outline" size="lg" className="backdrop-blur-sm">
              Go to Lab
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
