/**
 * Simple API wrapper with security headers
 */

function getSecurityHeaders() {
  const timestamp = Date.now();
  // Simple obfuscation to make it harder for casual observation
  const token = btoa(`nethunt-labr-${timestamp}-${Math.random().toString(36).substring(7)}`);
  return {
    "x-app-security-token": token,
    "x-requested-with": "XMLHttpRequest",
    "cache-control": "no-cache",
    "pragma": "no-cache"
  };
}

export async function api<T>(path: string, opts?: RequestInit): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    ...getSecurityHeaders(),
    ...(opts?.headers || {}),
  };

  const res = await fetch(`/api${path}`, { 
    ...opts, 
    headers 
  });

  if (res.status === 403) {
    const data = await res.clone().json().catch(() => ({}));
    if (data.blocked) {
      window.location.href = '/auth?blocked=true';
    }
  }

  if (!res.ok) throw await res.json().catch(()=>({ error: res.statusText }))
  return res.json()
}

export async function getJSON(path: string) {
  const res = await fetch(path, {
    headers: getSecurityHeaders()
  })
  
  if (res.status === 403) {
    const data = await res.clone().json().catch(() => ({}));
    if (data.blocked) {
      window.location.href = '/auth?blocked=true';
    }
  }

  if (!res.ok) throw new Error('Network error')
  return res.json()
}
